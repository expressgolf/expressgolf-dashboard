import React, { useState, useMemo, useEffect } from 'react';
import {
  LineChart, Line, AreaChart, Area, BarChart, Bar, XAxis, YAxis,
  CartesianGrid, Tooltip, ResponsiveContainer, Legend, ReferenceLine
} from 'recharts';
import { TrendingUp, TrendingDown, ShoppingCart, MousePointerClick, Percent, PoundSterling } from 'lucide-react';

// ---- Raw data (last 30 days, Express Golf — WooCommerce + Google Ads via Windsor.ai) ----

const wooDaily = {
  "2026-05-13": { revenue: 8302.20, orders: 32 },
  "2026-05-14": { revenue: 15987.12, orders: 39 },
  "2026-05-15": { revenue: 8318.59, orders: 31 },
  "2026-05-16": { revenue: 6920.83, orders: 29 },
  "2026-05-17": { revenue: 9854.30, orders: 35 },
  "2026-05-18": { revenue: 8214.39, orders: 27 },
  "2026-05-19": { revenue: 15062.60, orders: 40 },
  "2026-05-20": { revenue: 10822.14, orders: 35 },
  "2026-05-21": { revenue: 9279.14, orders: 30 },
  "2026-05-22": { revenue: 5448.30, orders: 26 },
  "2026-05-23": { revenue: 5044.80, orders: 18 },
  "2026-05-24": { revenue: 5408.07, orders: 23 },
  "2026-05-25": { revenue: 9762.89, orders: 27 },
  "2026-05-26": { revenue: 9444.65, orders: 33 },
  "2026-05-27": { revenue: 7817.28, orders: 35 },
  "2026-05-28": { revenue: 8658.15, orders: 34 },
  "2026-05-29": { revenue: 7608.13, orders: 24 },
  "2026-05-30": { revenue: 11035.58, orders: 28 },
  "2026-05-31": { revenue: 13554.18, orders: 38 },
  "2026-06-01": { revenue: 10408.67, orders: 32 },
  "2026-06-02": { revenue: 9390.77, orders: 34 },
  "2026-06-03": { revenue: 11648.28, orders: 38 },
  "2026-06-04": { revenue: 10831.15, orders: 39 },
  "2026-06-05": { revenue: 5399.97, orders: 19 },
  "2026-06-06": { revenue: 5589.58, orders: 21 },
  "2026-06-07": { revenue: 11708.59, orders: 32 },
  "2026-06-08": { revenue: 9850.81, orders: 36 },
  "2026-06-09": { revenue: 6231.75, orders: 27 },
  "2026-06-10": { revenue: 15867.57, orders: 48 },
  "2026-06-11": { revenue: 9150.21, orders: 42 },
};

const adsDaily = {
  "2026-05-13": { spend: 974.92, conv: 24.34, convValue: 8729.53, clicks: 1344, impr: 91299 },
  "2026-05-14": { spend: 822.76, conv: 32.50, convValue: 16862.00, clicks: 1157, impr: 85219 },
  "2026-05-15": { spend: 782.61, conv: 18.76, convValue: 5801.22, clicks: 998, impr: 75478 },
  "2026-05-16": { spend: 878.30, conv: 32.34, convValue: 10141.32, clicks: 1152, impr: 81562 },
  "2026-05-17": { spend: 1318.76, conv: 34.97, convValue: 12697.29, clicks: 1627, impr: 113786 },
  "2026-05-18": { spend: 956.06, conv: 24.63, convValue: 10114.34, clicks: 1241, impr: 88811 },
  "2026-05-19": { spend: 1076.95, conv: 25.46, convValue: 10853.74, clicks: 1301, impr: 95174 },
  "2026-05-20": { spend: 998.80, conv: 29.67, convValue: 10871.71, clicks: 1184, impr: 91529 },
  "2026-05-21": { spend: 860.92, conv: 19.63, convValue: 8031.60, clicks: 1076, impr: 80615 },
  "2026-05-22": { spend: 713.83, conv: 24.74, convValue: 6985.62, clicks: 990, impr: 63604 },
  "2026-05-23": { spend: 674.93, conv: 18.56, convValue: 5050.44, clicks: 948, impr: 57830 },
  "2026-05-24": { spend: 585.35, conv: 19.43, convValue: 4409.36, clicks: 811, impr: 52194 },
  "2026-05-25": { spend: 632.35, conv: 20.87, convValue: 7346.86, clicks: 908, impr: 55966 },
  "2026-05-26": { spend: 694.23, conv: 34.13, convValue: 11020.76, clicks: 730, impr: 51461 },
  "2026-05-27": { spend: 735.10, conv: 19.29, convValue: 6705.75, clicks: 788, impr: 53445 },
  "2026-05-28": { spend: 816.43, conv: 26.45, convValue: 8779.54, clicks: 835, impr: 56539 },
  "2026-05-29": { spend: 732.16, conv: 17.63, convValue: 8010.79, clicks: 710, impr: 54122 },
  "2026-05-30": { spend: 722.09, conv: 18.19, convValue: 7295.33, clicks: 728, impr: 52449 },
  "2026-05-31": { spend: 1174.12, conv: 27.66, convValue: 10023.34, clicks: 1170, impr: 78506 },
  "2026-06-01": { spend: 1029.97, conv: 28.83, convValue: 10261.19, clicks: 997, impr: 69571 },
  "2026-06-02": { spend: 1060.25, conv: 29.78, convValue: 10021.22, clicks: 1069, impr: 75106 },
  "2026-06-03": { spend: 1091.76, conv: 28.01, convValue: 10509.64, clicks: 1081, impr: 75458 },
  "2026-06-04": { spend: 1002.53, conv: 33.62, convValue: 11384.56, clicks: 1080, impr: 75405 },
  "2026-06-05": { spend: 732.76, conv: 18.08, convValue: 6813.01, clicks: 697, impr: 52944 },
  "2026-06-06": { spend: 850.82, conv: 14.94, convValue: 5689.64, clicks: 956, impr: 68668 },
  "2026-06-07": { spend: 869.11, conv: 24.45, convValue: 9426.17, clicks: 995, impr: 68765 },
  "2026-06-08": { spend: 789.97, conv: 30.00, convValue: 10149.81, clicks: 892, impr: 60688 },
  "2026-06-09": { spend: 628.06, conv: 14.23, convValue: 4271.08, clicks: 799, impr: 54120 },
  "2026-06-10": { spend: 816.92, conv: 26.32, convValue: 11924.27, clicks: 907, impr: 54642 },
  "2026-06-11": { spend: 750.23, conv: 26.16, convValue: 8025.79, clicks: 874, impr: 59179 },
};

const campaigns = [
  { name: "Golf Bags UK V2 (Brand)", spend: 8045.77, convValue: 89195.58, conv: 248.45, clicks: 9493, impr: 620514 },
  { name: "Performance Max: Putters UK", spend: 2162.68, convValue: 23039.86, conv: 55.94, clicks: 3837, impr: 231477 },
  { name: "Golf Bags UK V2 (Generic)", spend: 2124.24, convValue: 22257.67, conv: 62.65, clicks: 3636, impr: 258461 },
  { name: "Electric Trolleys UK", spend: 2973.66, convValue: 38929.83, conv: 49.57, clicks: 1357, impr: 127255 },
  { name: "Wedges UK", spend: 2409.30, convValue: 21249.96, conv: 63.00, clicks: 3011, impr: 197439 },
  { name: "Custom Irons UK", spend: 1249.90, convValue: 10696.12, conv: 17.15, clicks: 1677, impr: 140850 },
  { name: "Travel Bags UK", spend: 1075.24, convValue: 10076.25, conv: 66.83, clicks: 1006, impr: 57854 },
  { name: "Packages UK", spend: 1036.10, convValue: 9276.92, conv: 13.50, clicks: 585, impr: 44358 },
  { name: "Search: Branded UK", spend: 895.67, convValue: 12495.41, conv: 51.00, clicks: 1777, impr: 6353 },
  { name: "Push & Pull Trolleys UK", spend: 936.03, convValue: 9522.21, conv: 47.53, clicks: 694, impr: 59560 },
  { name: "Putters UK", spend: 799.99, convValue: 5931.95, conv: 19.37, clicks: 1054, impr: 89123 },
  { name: "GPS & Laser UK", spend: 660.37, convValue: 9467.20, conv: 26.99, clicks: 335, impr: 77579 },
  { name: "Fairways UK", spend: 467.37, convValue: 3352.46, conv: 11.69, clicks: 565, impr: 67264 },
  { name: "Drivers UK", spend: 467.42, convValue: 1310.07, conv: 3.01, clicks: 498, impr: 68660 },
  { name: "Hybrids & Utilities UK", spend: 215.64, convValue: 1335.45, conv: 6.00, clicks: 250, impr: 40583 },
  { name: "Search: Generic Bags UK", spend: 253.66, convValue: 69.99, conv: 1.00, clicks: 270, impr: 6805 },
];

// ---- Metorik gross profit data (daily) ----

// grossProfit = net revenue (ex-VAT) - product COGS  /  grossMargin = grossProfit / net revenue
const metorikGPByDate = {
  "2026-05-13": { grossProfit: 1982.78,  netProfit: 522.63,   grossMargin: 29.83 },
  "2026-05-14": { grossProfit: 4673.44,  netProfit: 3147.10,  grossMargin: 34.16 },
  "2026-05-15": { grossProfit: 2315.74,  netProfit: 1116.63,  grossMargin: 34.64 },
  "2026-05-16": { grossProfit: 1795.86,  netProfit: 502.44,   grossMargin: 31.12 },
  "2026-05-17": { grossProfit: 2479.82,  netProfit: 680.63,   grossMargin: 30.19 },
  "2026-05-18": { grossProfit: 2112.73,  netProfit: 714.60,   grossMargin: 29.13 },
  "2026-05-19": { grossProfit: 3950.25,  netProfit: 2297.62,  grossMargin: 34.92 },
  "2026-05-20": { grossProfit: 3198.15,  netProfit: 1689.94,  grossMargin: 35.59 },
  "2026-05-21": { grossProfit: 2278.94,  netProfit: 1026.02,  grossMargin: 29.24 },
  "2026-05-22": { grossProfit: 1370.50,  netProfit: 373.20,   grossMargin: 30.19 },
  "2026-05-23": { grossProfit: 1920.27,  netProfit: 963.96,   grossMargin: 36.08 },
  "2026-05-24": { grossProfit: 1323.13,  netProfit: 458.26,   grossMargin: 27.43 },
  "2026-05-25": { grossProfit: 2374.11,  netProfit: 1371.73,  grossMargin: 28.69 },
  "2026-05-26": { grossProfit: 2490.13,  netProfit: 1396.36,  grossMargin: 32.26 },
  "2026-05-27": { grossProfit: 1304.48,  netProfit: 181.41,   grossMargin: 28.99 },
  "2026-05-28": { grossProfit: 2193.89,  netProfit: 976.45,   grossMargin: 32.14 },
  "2026-05-29": { grossProfit: 1931.52,  netProfit: 857.84,   grossMargin: 31.65 },
  "2026-05-30": { grossProfit: 2974.27,  netProfit: 1795.49,  grossMargin: 32.39 },
  "2026-05-31": { grossProfit: 3662.43,  netProfit: 1886.82,  grossMargin: 31.89 },
  "2026-06-01": { grossProfit: 2662.95,  netProfit: 1134.24,  grossMargin: 31.92 },
  "2026-06-02": { grossProfit: 2072.04,  netProfit: 534.27,   grossMargin: 27.80 },
  "2026-06-03": { grossProfit: 2654.30,  netProfit: 1070.90,  grossMargin: 27.91 },
  "2026-06-04": { grossProfit: 2708.00,  netProfit: 1156.53,  grossMargin: 29.99 },
  "2026-06-05": { grossProfit: 1102.88,  netProfit: 98.90,    grossMargin: 29.12 },
  "2026-06-06": { grossProfit: 1536.96,  netProfit: 389.57,   grossMargin: 32.68 },
  "2026-06-07": { grossProfit: 3069.11,  netProfit: 1665.88,  grossMargin: 31.45 },
  "2026-06-08": { grossProfit: 2532.53,  netProfit: 1254.12,  grossMargin: 30.14 },
  "2026-06-09": { grossProfit: 1554.42,  netProfit: 561.96,   grossMargin: 32.08 },
  "2026-06-10": { grossProfit: 4035.57,  netProfit: 2564.17,  grossMargin: 30.51 },
  "2026-06-11": { grossProfit: 2238.05,  netProfit: 983.55,   grossMargin: 29.67 },
};

// ---- Category gross profit (from Metorik, 30d) ----

const categoryGP = [
  { name: "Golf Bags",          revenue: 75797.22, cogs: 52095.03, profit: 23702.19, margin: 31.27 },
  { name: "Electric Trolleys",  revenue: 38049.96, cogs: 27663.30, profit: 10386.66, margin: 27.30 },
  { name: "Irons",              revenue: 19584.79, cogs: 11086.41, profit: 8498.38,  margin: 43.39 },
  { name: "Package Sets",       revenue: 12391.73, cogs: 8233.85,  profit: 4157.88,  margin: 33.55 },
  { name: "Travel Bags",        revenue: 12045.87, cogs: 7931.31,  profit: 4114.56,  margin: 34.16 },
  { name: "Push Trolleys",      revenue: 9438.29,  cogs: 6580.63,  profit: 2857.66,  margin: 30.28 },
  { name: "GPS & Laser",        revenue: 9164.60,  cogs: 7128.80,  profit: 2035.80,  margin: 22.21 },
  { name: "Fairways",           revenue: 8970.65,  cogs: 5853.75,  profit: 3116.90,  margin: 34.75 },
  { name: "Drivers",            revenue: 7801.80,  cogs: 4942.09,  profit: 2859.71,  margin: 36.65 },
  { name: "Hybrids & Utilities",revenue: 4285.41,  cogs: 2834.53,  profit: 1450.88,  margin: 33.86 },
  { name: "Shoes",              revenue: 1940.56,  cogs: 1309.31,  profit: 631.25,   margin: 32.53 },
  { name: "Balls",              revenue: 1935.93,  cogs: 1559.54,  profit: 376.39,   margin: 19.44 },
  { name: "Gloves",             revenue: 588.11,   cogs: 407.61,   profit: 180.50,   margin: 30.69 },
];

// ---- Traffic channel data (GA4, 30d — GP estimated at store average 31.29%) ----
// GA4 revenue is VAT-inclusive; scaled to Metorik net via ratio 231724/285532 = 0.8116
// GP = net × 31.29% (product COGS not tracked per channel — store average applied)
const GA4_TO_NET = 0.8116;
const channelData = [
  { channel: "Paid Ads",  icon: "🎯", sessions: 29456, orders: 570, gaRev: 176549.83,
    note: "Paid Shopping + Paid Search + Cross-network" },
  { channel: "Organic",   icon: "🌿", sessions: 14864, orders: 168, gaRev: 42509.78,
    note: "Organic Search + Organic Shopping" },
  { channel: "Direct",    icon: "🔗", sessions: 8305,  orders: 90,  gaRev: 24154.84,
    note: "Direct / (none)" },
  { channel: "Email",     icon: "📧", sessions: 3309,  orders: 28,  gaRev: 7557.76,
    note: "Mailchimp" },
  { channel: "Social",    icon: "📱", sessions: 48,    orders: 0,   gaRev: 0,
    note: "Organic Social" },
  { channel: "Other",     icon: "⚪", sessions: 4728,  orders: 160, gaRev: 34759.79,
    note: "Unassigned + Referral + AI Assistant" },
].map(c => ({
  ...c,
  net: +(c.gaRev * GA4_TO_NET).toFixed(2),
  gp: +(c.gaRev * GA4_TO_NET * 0.3129).toFixed(2),
  margin: 31.29,
  aov: c.orders > 0 ? +((c.gaRev * GA4_TO_NET) / c.orders).toFixed(2) : 0,
  convRate: c.sessions > 0 ? +((c.orders / c.sessions) * 100).toFixed(2) : 0,
}));

// ---- Payment method gross profit (Metorik, 30d) ----
// GP = net revenue (ex-VAT) - product COGS  (ad spend excluded — Metorik allocates full ad spend to every filter)
const paymentMethodGP = [
  { method: "Card",      icon: "💳", orders: 307, net: 71075.55, cogs: 48516.84, gp: 22558.71, margin: 31.74 },
  { method: "Apple Pay", icon: "🍎", orders: 345, net: 71392.29, cogs: 50217.19, gp: 21175.10, margin: 29.66 },
  { method: "Klarna",    icon: "🟣", orders: 127, net: 45500.61, cogs: 30941.23, gp: 14559.38, margin: 32.00 },
  { method: "PayPal",    icon: "🅿️", orders: 182, net: 41167.86, cogs: 27735.51, gp: 13432.35, margin: 32.63 },
  { method: "Clearpay",  icon: "✅", orders: 14,  net: 2588.37,  cogs: 1847.21,  gp: 741.16,   margin: 28.63 },
];

// ---- Derived series ----

const dates = Object.keys(wooDaily).sort();

const series = dates.map((d) => {
  const w = wooDaily[d];
  const a = adsDaily[d];
  const gp = metorikGPByDate[d] || { grossProfit: 0, netProfit: 0, grossMargin: 0 };
  const label = new Date(d + "T00:00:00").toLocaleDateString("en-GB", { day: "numeric", month: "short" });
  return {
    date: d,
    label,
    revenue: Math.round(w.revenue),
    orders: w.orders,
    spend: Math.round(a.spend),
    roas: a.spend > 0 ? +(a.convValue / a.spend).toFixed(2) : 0,
    aov: w.orders > 0 ? +(w.revenue / w.orders).toFixed(2) : 0,
    convValue: Math.round(a.convValue),
    cpc: a.clicks > 0 ? +(a.spend / a.clicks).toFixed(2) : 0,
    acosPct: w.revenue > 0 ? +((a.spend / w.revenue) * 100).toFixed(2) : 0,
    grossProfit: Math.round(gp.grossProfit),
    netProfit: Math.round(gp.netProfit),
    grossMargin: gp.grossMargin,
  };
});

const sum = (arr, key) => arr.reduce((s, x) => s + x[key], 0);
const totalRevenue = sum(series, "revenue");
const totalSpend = sum(series, "spend");
const totalOrders = sum(series, "orders");
const totalConvValue = sum(series, "convValue");
const avgRoas = totalSpend > 0 ? totalConvValue / totalSpend : 0;
const avgAov = totalOrders > 0 ? totalRevenue / totalOrders : 0;
const acos = totalRevenue > 0 ? (totalSpend / totalRevenue) * 100 : 0;
const avgCps = totalOrders > 0 ? totalSpend / totalOrders : 0; // ad spend ÷ WooCommerce orders

// split into two halves for trend comparison
const mid = Math.floor(series.length / 2);
const firstHalf = series.slice(0, mid);
const secondHalf = series.slice(mid);
const pctChange = (a, b) => (a === 0 ? 0 : ((b - a) / a) * 100);
const revenueTrend = pctChange(sum(firstHalf, "revenue"), sum(secondHalf, "revenue"));
const spendTrend = pctChange(sum(firstHalf, "spend"), sum(secondHalf, "spend"));
const roasFirst = sum(firstHalf, "spend") > 0 ? sum(firstHalf, "convValue") / sum(firstHalf, "spend") : 0;
const roasSecond = sum(secondHalf, "spend") > 0 ? sum(secondHalf, "convValue") / sum(secondHalf, "spend") : 0;
const roasTrend = pctChange(roasFirst, roasSecond);
const ordersTrend = pctChange(sum(firstHalf, "orders"), sum(secondHalf, "orders"));
const acosFirst = sum(firstHalf, "spend") > 0 ? (sum(firstHalf, "spend") / sum(firstHalf, "revenue")) * 100 : 0;
const acosSecond = sum(secondHalf, "spend") > 0 ? (sum(secondHalf, "spend") / sum(secondHalf, "revenue")) * 100 : 0;
const acosTrend = pctChange(acosFirst, acosSecond);
const cpsFirst = sum(firstHalf, "orders") > 0 ? sum(firstHalf, "spend") / sum(firstHalf, "orders") : 0;
const cpsSecond = sum(secondHalf, "orders") > 0 ? sum(secondHalf, "spend") / sum(secondHalf, "orders") : 0;
const cpsTrend = pctChange(cpsFirst, cpsSecond);

// GP totals (Metorik) — gross profit = net revenue (ex-VAT) - product COGS
const totalGrossProfit = 72499.25;   // 231,724.68 net revenue - 159,225.43 product COGS
const totalGrossMargin = 31.29;      // 72,499.25 / 231,724.68
const totalNetProfit = 33373.22;     // after product COGS + shipping + transaction fees + ad spend
const totalNetMargin = 14.4;         // 33,373.22 / 231,724.68
const gpTrend = pctChange(sum(firstHalf, "grossProfit"), sum(secondHalf, "grossProfit"));
const npTrend = pctChange(sum(firstHalf, "netProfit"), sum(secondHalf, "netProfit"));
const gpMarginFirst = sum(firstHalf, "revenue") > 0 ? (sum(firstHalf, "grossProfit") / sum(firstHalf, "revenue")) * 100 : 0;
const gpMarginSecond = sum(secondHalf, "revenue") > 0 ? (sum(secondHalf, "grossProfit") / sum(secondHalf, "revenue")) * 100 : 0;
const gpMarginTrend = pctChange(gpMarginFirst, gpMarginSecond);

const sortedCampaigns = [...campaigns].sort((a, b) => b.convValue - a.convValue);

const fmtGBP = (n) =>
  new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP", maximumFractionDigits: 0 }).format(n);
const fmtGBP2 = (n) =>
  new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP", maximumFractionDigits: 2 }).format(n);

// ---- Components ----

function StatCard({ icon: Icon, label, value, trend, trendLabel, accentStyle, invertTrend }) {
  const isGood = invertTrend ? trend <= 0 : trend >= 0;
  const TrendIcon = trend >= 0 ? TrendingUp : TrendingDown;
  return (
    <div className="rounded-2xl border p-5 flex flex-col gap-3 shadow-sm" style={{ background: '#f7f8f0', borderColor: '#023c4622' }}>
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold uppercase tracking-wider" style={{ color: '#023c46', opacity: 0.5 }}>{label}</span>
        <div className="w-8 h-8 rounded-full flex items-center justify-center" style={accentStyle}>
          <Icon size={16} style={{ color: '#023c46' }} />
        </div>
      </div>
      <div className="text-2xl font-bold tabular-nums" style={{ color: '#023c46' }}>{value}</div>
      <div className={`flex items-center gap-1 text-xs font-medium ${isGood ? "text-emerald-600" : "text-rose-500"}`}>
        <TrendIcon size={14} />
        <span>{Math.abs(trend).toFixed(1)}% {trendLabel}</span>
      </div>
    </div>
  );
}

function CustomTooltip({ active, payload, label, formatter }) {
  if (!active || !payload || !payload.length) return null;
  return (
    <div className="rounded-lg shadow-md px-3 py-2 text-xs" style={{ background: '#f7f8f0', border: '1px solid #023c4622' }}>
      <div className="font-semibold mb-1" style={{ color: '#023c46' }}>{label}</div>
      {payload.map((p) => (
        <div key={p.dataKey} className="flex items-center gap-2" style={{ color: '#023c46', opacity: 0.75 }}>
          <span className="w-2 h-2 rounded-full" style={{ background: p.color }} />
          <span>{p.name}:</span>
          <span className="font-semibold" style={{ color: '#023c46', opacity: 1 }}>{formatter ? formatter(p.dataKey, p.value) : p.value}</span>
        </div>
      ))}
    </div>
  );
}

export default function Dashboard() {
  const [range, setRange] = useState(30);

  useEffect(() => {
    const link = document.createElement('link');
    link.href = 'https://fonts.googleapis.com/css2?family=Montserrat:wght@900&display=swap';
    link.rel = 'stylesheet';
    document.head.appendChild(link);
  }, []);

  const visible = useMemo(() => series.slice(series.length - range), [range]);

  return (
    <div className="min-h-screen font-sans p-6 md:p-10" style={{ background: '#f7f8f0', color: '#023c46' }}>
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-8">
          <div>
            {/* Logo */}
            <div className="mb-3" style={{
              fontFamily: "'Montserrat', 'Arial Black', sans-serif",
              fontWeight: 900,
              fontSize: 22,
              letterSpacing: '-0.5px',
              color: '#023c46',
              lineHeight: 1,
            }}>EXPRESSGOLF.</div>
            <p className="text-sm mt-1" style={{ color: '#023c46', opacity: 0.5 }}>
              Store &amp; Ad Performance · WooCommerce + Google Ads, last {range} days
            </p>
          </div>
          <div className="flex gap-2">
            {[7, 14, 30].map((r) => (
              <button
                key={r}
                onClick={() => setRange(r)}
                className="px-4 py-2 rounded-full text-sm font-medium border transition-colors"
                style={range === r
                  ? { background: '#023c46', color: '#85FF85', borderColor: '#023c46' }
                  : { background: '#f7f8f0', color: '#023c46', borderColor: '#023c4644' }}
              >
                {r}d
              </button>
            ))}
          </div>
        </div>

        {/* Stat cards */}
        <div className="grid grid-cols-2 lg:grid-cols-6 gap-4 mb-8">
          <StatCard
            icon={PoundSterling}
            label="Revenue"
            value={fmtGBP(totalRevenue)}
            trend={revenueTrend}
            trendLabel="vs first half"
            accentStyle={{ background: '#85FF85' }}
          />
          <StatCard
            icon={ShoppingCart}
            label="Orders"
            value={totalOrders.toLocaleString()}
            trend={ordersTrend}
            trendLabel="vs first half"
            accentStyle={{ background: '#023c46' }}
          />
          <StatCard
            icon={MousePointerClick}
            label="Ad spend"
            value={fmtGBP(totalSpend)}
            trend={spendTrend}
            trendLabel="vs first half"
            accentStyle={{ background: '#023c4699' }}
          />
          <StatCard
            icon={Percent}
            label="Avg ROAS"
            value={`${avgRoas.toFixed(2)}x`}
            trend={roasTrend}
            trendLabel="vs first half"
            accentStyle={{ background: '#85FF85', filter: 'brightness(0.85)' }}
          />
          <StatCard
            icon={Percent}
            label="Ad Spend / Revenue"
            value={`${acos.toFixed(1)}%`}
            trend={acosTrend}
            trendLabel="vs first half"
            accentStyle={{ background: '#023c4666' }}
            invertTrend
          />
          <StatCard
            icon={PoundSterling}
            label="Cost Per Sale"
            value={fmtGBP2(avgCps)}
            trend={cpsTrend}
            trendLabel="vs first half"
            accentStyle={{ background: '#023c4644' }}
            invertTrend
          />
        </div>

        {/* Revenue + spend chart */}
        <div className="rounded-2xl border p-5 mb-6 shadow-sm" style={{ background: '#ffffff', borderColor: '#023c4622' }}>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold" style={{ color: '#023c46' }}>Revenue vs. Ad Spend</h2>
            <div className="flex items-center gap-4 text-xs" style={{ color: '#023c46', opacity: 0.5 }}>
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full" style={{ background: '#85FF85', border: '1px solid #023c4633' }} />Revenue</span>
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full" style={{ background: '#023c4699' }} />Ad spend</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={visible} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#85FF85" stopOpacity={0.35} />
                  <stop offset="100%" stopColor="#85FF85" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#023c460f" vertical={false} />
              <XAxis dataKey="label" tick={{ fontSize: 11, fill: "#023c4666" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "#023c4666" }} axisLine={false} tickLine={false} tickFormatter={(v) => `£${v / 1000}k`} />
              <Tooltip content={<CustomTooltip formatter={(_, v) => fmtGBP(v)} />} />
              <Area type="monotone" dataKey="revenue" name="Revenue" stroke="#85FF85" strokeWidth={2} fill="url(#revGrad)" />
              <Line type="monotone" dataKey="spend" name="Ad spend" stroke="#023c4699" strokeWidth={2} dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* ROAS chart */}
          <div className="rounded-2xl border p-5 shadow-sm" style={{ background: '#ffffff', borderColor: '#023c4622' }}>
            <h2 className="text-sm font-semibold mb-4" style={{ color: '#023c46' }}>Return on Ad Spend (ROAS)</h2>
            <ResponsiveContainer width="100%" height={220}>
              <LineChart data={visible} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#023c460f" vertical={false} />
                <XAxis dataKey="label" tick={{ fontSize: 11, fill: "#023c4666" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "#023c4666" }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v}x`} />
                <Tooltip content={<CustomTooltip formatter={(_, v) => `${v}x`} />} />
                <Line type="monotone" dataKey="roas" name="ROAS" stroke="#023c46" strokeWidth={2} dot={{ r: 2, fill: '#85FF85', stroke: '#023c46' }} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* AOV chart */}
          <div className="rounded-2xl border p-5 shadow-sm" style={{ background: '#ffffff', borderColor: '#023c4622' }}>
            <h2 className="text-sm font-semibold mb-4" style={{ color: '#023c46' }}>Average Order Value</h2>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={visible} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#023c460f" vertical={false} />
                <XAxis dataKey="label" tick={{ fontSize: 11, fill: "#023c4666" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "#023c4666" }} axisLine={false} tickLine={false} tickFormatter={(v) => `£${v}`} />
                <Tooltip content={<CustomTooltip formatter={(_, v) => fmtGBP2(v)} />} />
                <Bar dataKey="aov" name="AOV" fill="#85FF85" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Ad Spend % of Revenue chart */}
        <div className="rounded-2xl border p-5 mb-6 shadow-sm" style={{ background: '#ffffff', borderColor: '#023c4622' }}>
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-semibold" style={{ color: '#023c46' }}>Ad Spend as % of Gross Revenue</h2>
              <p className="text-xs mt-0.5" style={{ color: '#023c46', opacity: 0.45 }}>Daily ad spend ÷ WooCommerce revenue — lower is better</p>
            </div>
            <div className="text-right">
              <div className="text-lg font-bold tabular-nums" style={{ color: '#023c46' }}>{acos.toFixed(1)}%</div>
              <div className="text-xs" style={{ color: '#023c46', opacity: 0.4 }}>30d average</div>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={240}>
            <AreaChart data={visible} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="acosGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#023c46" stopOpacity={0.15} />
                  <stop offset="100%" stopColor="#023c46" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#023c460f" vertical={false} />
              <XAxis dataKey="label" tick={{ fontSize: 11, fill: "#023c4666" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "#023c4666" }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v}%`} domain={[0, 'auto']} />
              <Tooltip content={<CustomTooltip formatter={(_, v) => `${v}%`} />} />
              <ReferenceLine y={acos} stroke="#85FF85" strokeDasharray="4 3" strokeWidth={1.5} label={{ value: `Avg ${acos.toFixed(1)}%`, position: 'insideTopRight', fontSize: 10, fill: '#023c4699' }} />
              <Area type="monotone" dataKey="acosPct" name="Ad spend %" stroke="#023c46" strokeWidth={2} fill="url(#acosGrad)" dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* ---- Gross Profit Section ---- */}
        <div className="mt-10 mb-4">
          <div className="text-xs font-semibold uppercase tracking-[0.2em] mb-1" style={{ color: '#85FF85', WebkitTextStroke: '0.5px #023c4666' }}>Gross Profit</div>
          <h2 className="text-xl font-bold" style={{ color: '#023c46' }}>Profitability Overview</h2>
          <p className="text-xs mt-0.5" style={{ color: '#023c46', opacity: 0.45 }}>Source: Metorik · 30 days to 11 Jun 2026</p>
        </div>

        {/* GP stat cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <StatCard icon={PoundSterling} label="Gross Profit" value={fmtGBP(totalGrossProfit)} trend={gpTrend} trendLabel="vs first half" accentStyle={{ background: '#85FF85' }} />
          <StatCard icon={Percent} label="Gross Margin" value={`${totalGrossMargin.toFixed(1)}%`} trend={gpMarginTrend} trendLabel="vs first half" accentStyle={{ background: '#85FF85', filter: 'brightness(0.85)' }} />
          <StatCard icon={PoundSterling} label="Net Profit" value={fmtGBP(totalNetProfit)} trend={npTrend} trendLabel="vs first half" accentStyle={{ background: '#023c46' }} />
          <StatCard icon={Percent} label="Net Margin" value={`${totalNetMargin.toFixed(1)}%`} trend={npTrend} trendLabel="vs first half" accentStyle={{ background: '#023c4699' }} />
        </div>

        {/* GP over time chart */}
        <div className="rounded-2xl border p-5 mb-6 shadow-sm" style={{ background: '#ffffff', borderColor: '#023c4622' }}>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold" style={{ color: '#023c46' }}>Gross &amp; Net Profit Over Time</h2>
            <div className="flex items-center gap-4 text-xs" style={{ color: '#023c46', opacity: 0.5 }}>
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full" style={{ background: '#85FF85', border: '1px solid #023c4633' }} />Gross profit</span>
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full" style={{ background: '#023c46' }} />Net profit</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={240}>
            <AreaChart data={visible} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="gpGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#85FF85" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="#85FF85" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="npGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#023c46" stopOpacity={0.2} />
                  <stop offset="100%" stopColor="#023c46" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#023c460f" vertical={false} />
              <XAxis dataKey="label" tick={{ fontSize: 11, fill: "#023c4666" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "#023c4666" }} axisLine={false} tickLine={false} tickFormatter={(v) => `£${v / 1000}k`} />
              <Tooltip content={<CustomTooltip formatter={(_, v) => fmtGBP(v)} />} />
              <Area type="monotone" dataKey="grossProfit" name="Gross profit" stroke="#85FF85" strokeWidth={2} fill="url(#gpGrad)" />
              <Area type="monotone" dataKey="netProfit" name="Net profit" stroke="#023c46" strokeWidth={2} fill="url(#npGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Category GP table */}
        <div className="rounded-2xl border p-5 mb-6 shadow-sm" style={{ background: '#ffffff', borderColor: '#023c4622' }}>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold" style={{ color: '#023c46' }}>Gross Profit by Category (30d)</h2>
            <span className="text-xs" style={{ color: '#023c46', opacity: 0.4 }}>Overall GP: {totalGrossMargin.toFixed(1)}%</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs uppercase tracking-wider" style={{ color: '#023c46', opacity: 0.45, borderBottom: '1px solid #023c4615' }}>
                  <th className="py-2 pr-4 font-semibold">Category</th>
                  <th className="py-2 pr-4 font-semibold text-right">Net Revenue</th>
                  <th className="py-2 pr-4 font-semibold text-right">COGS</th>
                  <th className="py-2 pr-4 font-semibold text-right">Gross Profit</th>
                  <th className="py-2 pr-4 font-semibold text-right">GP %</th>
                  <th className="py-2 font-semibold text-right">GP Bar</th>
                </tr>
              </thead>
              <tbody>
                {categoryGP.map((c) => (
                  <tr key={c.name} style={{ borderBottom: '1px solid #023c460a' }}>
                    <td className="py-2.5 pr-4 font-medium" style={{ color: '#023c46' }}>{c.name}</td>
                    <td className="py-2.5 pr-4 text-right tabular-nums" style={{ color: '#023c4699' }}>{fmtGBP(c.revenue)}</td>
                    <td className="py-2.5 pr-4 text-right tabular-nums" style={{ color: '#023c4699' }}>{fmtGBP(c.cogs)}</td>
                    <td className="py-2.5 pr-4 text-right tabular-nums font-semibold" style={{ color: '#023c46' }}>{fmtGBP(c.profit)}</td>
                    <td className="py-2.5 pr-4 text-right tabular-nums font-semibold">
                      <span style={{ color: c.margin >= 40 ? '#059669' : c.margin >= 30 ? '#023c46' : '#d97706' }}>
                        {c.margin.toFixed(1)}%
                      </span>
                    </td>
                    <td className="py-2.5 text-right" style={{ minWidth: 100 }}>
                      <div className="flex items-center justify-end gap-2">
                        <div className="h-2 rounded-full" style={{
                          width: `${Math.round((c.profit / categoryGP[0].profit) * 80)}px`,
                          background: c.margin >= 40 ? '#85FF85' : c.margin >= 30 ? '#023c4666' : '#f59e0b',
                          minWidth: 4,
                        }} />
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr style={{ borderTop: '2px solid #023c4622' }}>
                  <td className="py-2.5 pr-4 font-bold text-xs uppercase tracking-wider" style={{ color: '#023c46' }}>Total</td>
                  <td className="py-2.5 pr-4 text-right tabular-nums font-bold" style={{ color: '#023c46' }}>{fmtGBP(categoryGP.reduce((s, c) => s + c.revenue, 0))}</td>
                  <td className="py-2.5 pr-4 text-right tabular-nums font-bold" style={{ color: '#023c46' }}>{fmtGBP(categoryGP.reduce((s, c) => s + c.cogs, 0))}</td>
                  <td className="py-2.5 pr-4 text-right tabular-nums font-bold" style={{ color: '#023c46' }}>{fmtGBP(categoryGP.reduce((s, c) => s + c.profit, 0))}</td>
                  <td className="py-2.5 pr-4 text-right tabular-nums font-bold" style={{ color: '#023c46' }}>
                    {(categoryGP.reduce((s, c) => s + c.profit, 0) / categoryGP.reduce((s, c) => s + c.revenue, 0) * 100).toFixed(1)}%
                  </td>
                  <td />
                </tr>
              </tfoot>
            </table>
          </div>
        </div>

        {/* ---- Payment Method Section ---- */}
        <div className="mt-10 mb-4">
          <div className="text-xs font-semibold uppercase tracking-[0.2em] mb-1" style={{ color: '#85FF85', WebkitTextStroke: '0.5px #023c4666' }}>Checkout</div>
          <h2 className="text-xl font-bold" style={{ color: '#023c46' }}>Sales by Payment Method</h2>
          <p className="text-xs mt-0.5" style={{ color: '#023c46', opacity: 0.45 }}>Source: Metorik · 30 days to 11 Jun 2026 · GP = net revenue (ex-VAT) – product COGS</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Payment method bar chart */}
          <div className="rounded-2xl border p-5 shadow-sm" style={{ background: '#ffffff', borderColor: '#023c4622' }}>
            <h2 className="text-sm font-semibold mb-4" style={{ color: '#023c46' }}>Net Revenue &amp; Gross Profit by Method</h2>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={paymentMethodGP} layout="vertical" margin={{ top: 0, right: 16, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#023c460f" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 11, fill: "#023c4666" }} axisLine={false} tickLine={false} tickFormatter={(v) => `£${v / 1000}k`} />
                <YAxis type="category" dataKey="method" tick={{ fontSize: 12, fill: "#023c46", fontWeight: 500 }} axisLine={false} tickLine={false} width={72} />
                <Tooltip content={<CustomTooltip formatter={(_, v) => fmtGBP(v)} />} />
                <Bar dataKey="net" name="Net Revenue" fill="#023c4622" radius={[0, 3, 3, 0]} />
                <Bar dataKey="gp" name="Gross Profit" fill="#85FF85" radius={[0, 3, 3, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* GP % by method */}
          <div className="rounded-2xl border p-5 shadow-sm" style={{ background: '#ffffff', borderColor: '#023c4622' }}>
            <h2 className="text-sm font-semibold mb-4" style={{ color: '#023c46' }}>Gross Margin % by Method</h2>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={paymentMethodGP} layout="vertical" margin={{ top: 0, right: 16, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#023c460f" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 11, fill: "#023c4666" }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v}%`} domain={[0, 40]} />
                <YAxis type="category" dataKey="method" tick={{ fontSize: 12, fill: "#023c46", fontWeight: 500 }} axisLine={false} tickLine={false} width={72} />
                <Tooltip content={<CustomTooltip formatter={(_, v) => `${v}%`} />} />
                <ReferenceLine x={totalGrossMargin} stroke="#023c4666" strokeDasharray="4 3" label={{ value: `Avg ${totalGrossMargin.toFixed(1)}%`, position: 'insideTopRight', fontSize: 10, fill: '#023c4699' }} />
                <Bar dataKey="margin" name="GP %" radius={[0, 3, 3, 0]}
                  fill="#85FF85"
                  label={{ position: 'insideRight', fontSize: 11, fill: '#023c46', formatter: (v) => `${v.toFixed(1)}%` }}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Payment method table */}
        <div className="rounded-2xl border p-5 mb-6 shadow-sm" style={{ background: '#ffffff', borderColor: '#023c4622' }}>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold" style={{ color: '#023c46' }}>Payment Method Breakdown (30d)</h2>
            <span className="text-xs" style={{ color: '#023c46', opacity: 0.4 }}>
              {paymentMethodGP.reduce((s, m) => s + m.orders, 0)} orders · {fmtGBP(paymentMethodGP.reduce((s, m) => s + m.net, 0))} net revenue
            </span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs uppercase tracking-wider" style={{ color: '#023c46', opacity: 0.45, borderBottom: '1px solid #023c4615' }}>
                  <th className="py-2 pr-4 font-semibold">Method</th>
                  <th className="py-2 pr-4 font-semibold text-right">Orders</th>
                  <th className="py-2 pr-4 font-semibold text-right">Share</th>
                  <th className="py-2 pr-4 font-semibold text-right">Net Revenue</th>
                  <th className="py-2 pr-4 font-semibold text-right">Gross Profit</th>
                  <th className="py-2 pr-4 font-semibold text-right">GP %</th>
                  <th className="py-2 font-semibold text-right">AOV</th>
                </tr>
              </thead>
              <tbody>
                {paymentMethodGP.map((m) => {
                  const totalOrders_pm = paymentMethodGP.reduce((s, x) => s + x.orders, 0);
                  const share = totalOrders_pm > 0 ? (m.orders / totalOrders_pm) * 100 : 0;
                  const aov_pm = m.orders > 0 ? m.net / m.orders : 0;
                  return (
                    <tr key={m.method} style={{ borderBottom: '1px solid #023c460a' }}>
                      <td className="py-2.5 pr-4 font-medium" style={{ color: '#023c46' }}>
                        <span className="mr-1.5">{m.icon}</span>{m.method}
                      </td>
                      <td className="py-2.5 pr-4 text-right tabular-nums" style={{ color: '#023c4699' }}>{m.orders}</td>
                      <td className="py-2.5 pr-4 text-right tabular-nums" style={{ color: '#023c4699' }}>
                        <div className="flex items-center justify-end gap-2">
                          <div className="h-1.5 rounded-full" style={{ width: `${Math.round(share * 1.5)}px`, background: '#023c4644', minWidth: 4 }} />
                          {share.toFixed(1)}%
                        </div>
                      </td>
                      <td className="py-2.5 pr-4 text-right tabular-nums" style={{ color: '#023c4699' }}>{fmtGBP(m.net)}</td>
                      <td className="py-2.5 pr-4 text-right tabular-nums font-semibold" style={{ color: '#023c46' }}>{fmtGBP(m.gp)}</td>
                      <td className="py-2.5 pr-4 text-right tabular-nums font-semibold">
                        <span style={{ color: m.margin >= 33 ? '#059669' : m.margin >= 30 ? '#d97706' : '#e11d48' }}>
                          {m.margin.toFixed(1)}%
                        </span>
                      </td>
                      <td className="py-2.5 text-right tabular-nums" style={{ color: '#023c4699' }}>{fmtGBP2(aov_pm)}</td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot>
                <tr style={{ borderTop: '2px solid #023c4622' }}>
                  <td className="py-2.5 pr-4 font-bold text-xs uppercase tracking-wider" style={{ color: '#023c46' }}>Total</td>
                  <td className="py-2.5 pr-4 text-right tabular-nums font-bold" style={{ color: '#023c46' }}>{paymentMethodGP.reduce((s, m) => s + m.orders, 0)}</td>
                  <td className="py-2.5 pr-4 text-right tabular-nums font-bold" style={{ color: '#023c46' }}>100%</td>
                  <td className="py-2.5 pr-4 text-right tabular-nums font-bold" style={{ color: '#023c46' }}>{fmtGBP(paymentMethodGP.reduce((s, m) => s + m.net, 0))}</td>
                  <td className="py-2.5 pr-4 text-right tabular-nums font-bold" style={{ color: '#023c46' }}>{fmtGBP(paymentMethodGP.reduce((s, m) => s + m.gp, 0))}</td>
                  <td className="py-2.5 pr-4 text-right tabular-nums font-bold" style={{ color: '#023c46' }}>
                    {(paymentMethodGP.reduce((s, m) => s + m.gp, 0) / paymentMethodGP.reduce((s, m) => s + m.net, 0) * 100).toFixed(1)}%
                  </td>
                  <td className="py-2.5 text-right tabular-nums font-bold" style={{ color: '#023c46' }}>
                    {fmtGBP2(paymentMethodGP.reduce((s, m) => s + m.net, 0) / paymentMethodGP.reduce((s, m) => s + m.orders, 0))}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>

        {/* ---- Traffic Channel Section ---- */}
        <div className="mt-10 mb-4">
          <div className="text-xs font-semibold uppercase tracking-[0.2em] mb-1" style={{ color: '#85FF85', WebkitTextStroke: '0.5px #023c4666' }}>Attribution</div>
          <h2 className="text-xl font-bold" style={{ color: '#023c46' }}>Revenue by Traffic Channel</h2>
          <p className="text-xs mt-0.5" style={{ color: '#023c46', opacity: 0.45 }}>
            Source: Google Analytics 4 · 30 days to 11 Jun 2026 · GP estimated at store avg margin (31.3%)
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Channel revenue bar chart */}
          <div className="rounded-2xl border p-5 shadow-sm" style={{ background: '#ffffff', borderColor: '#023c4622' }}>
            <h2 className="text-sm font-semibold mb-4" style={{ color: '#023c46' }}>Net Revenue &amp; Gross Profit by Channel</h2>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={channelData.filter(c => c.net > 0)} layout="vertical" margin={{ top: 0, right: 16, left: 8, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#023c460f" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 11, fill: "#023c4666" }} axisLine={false} tickLine={false} tickFormatter={(v) => `£${v / 1000}k`} />
                <YAxis type="category" dataKey="channel" tick={{ fontSize: 12, fill: "#023c46", fontWeight: 500 }} axisLine={false} tickLine={false} width={72} />
                <Tooltip content={<CustomTooltip formatter={(_, v) => fmtGBP(v)} />} />
                <Bar dataKey="net" name="Net Revenue" fill="#023c4622" radius={[0, 3, 3, 0]} />
                <Bar dataKey="gp" name="Est. Gross Profit" fill="#85FF85" radius={[0, 3, 3, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Conversion rate by channel */}
          <div className="rounded-2xl border p-5 shadow-sm" style={{ background: '#ffffff', borderColor: '#023c4622' }}>
            <h2 className="text-sm font-semibold mb-4" style={{ color: '#023c46' }}>Conversion Rate &amp; AOV by Channel</h2>
            <div className="space-y-3 mt-2">
              {channelData.filter(c => c.orders > 0).map(c => (
                <div key={c.channel}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-medium flex items-center gap-1.5" style={{ color: '#023c46' }}>
                      <span>{c.icon}</span>{c.channel}
                    </span>
                    <div className="flex items-center gap-4 text-xs" style={{ color: '#023c46', opacity: 0.7 }}>
                      <span className="font-semibold">{c.convRate}%</span>
                      <span className="tabular-nums">{fmtGBP2(c.aov)} AOV</span>
                    </div>
                  </div>
                  <div className="h-2 rounded-full" style={{ background: '#023c460f' }}>
                    <div className="h-2 rounded-full" style={{
                      width: `${Math.min((c.convRate / 3.5) * 100, 100)}%`,
                      background: c.channel === 'Paid Ads' ? '#85FF85' : '#023c4666',
                    }} />
                  </div>
                </div>
              ))}
            </div>
            <p className="text-xs mt-4" style={{ color: '#023c46', opacity: 0.35 }}>Conv rate = GA4 transactions ÷ sessions</p>
          </div>
        </div>

        {/* Channel table */}
        <div className="rounded-2xl border p-5 mb-6 shadow-sm" style={{ background: '#ffffff', borderColor: '#023c4622' }}>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold" style={{ color: '#023c46' }}>Channel Breakdown (30d)</h2>
            <span className="text-xs" style={{ color: '#023c46', opacity: 0.4 }}>
              {channelData.reduce((s, c) => s + c.orders, 0).toLocaleString()} orders · {channelData.reduce((s, c) => s + c.sessions, 0).toLocaleString()} sessions
            </span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs uppercase tracking-wider" style={{ color: '#023c46', opacity: 0.45, borderBottom: '1px solid #023c4615' }}>
                  <th className="py-2 pr-4 font-semibold">Channel</th>
                  <th className="py-2 pr-4 font-semibold text-right">Sessions</th>
                  <th className="py-2 pr-4 font-semibold text-right">Orders</th>
                  <th className="py-2 pr-4 font-semibold text-right">Conv %</th>
                  <th className="py-2 pr-4 font-semibold text-right">Net Revenue</th>
                  <th className="py-2 pr-4 font-semibold text-right">Est. GP</th>
                  <th className="py-2 font-semibold text-right">AOV</th>
                </tr>
              </thead>
              <tbody>
                {channelData.map((c) => (
                  <tr key={c.channel} style={{ borderBottom: '1px solid #023c460a' }}>
                    <td className="py-2.5 pr-4 font-medium" style={{ color: '#023c46' }}>
                      <span className="mr-1.5">{c.icon}</span>{c.channel}
                      <span className="ml-1.5 text-xs font-normal" style={{ color: '#023c46', opacity: 0.35 }}>{c.note}</span>
                    </td>
                    <td className="py-2.5 pr-4 text-right tabular-nums" style={{ color: '#023c4699' }}>{c.sessions.toLocaleString()}</td>
                    <td className="py-2.5 pr-4 text-right tabular-nums" style={{ color: '#023c4699' }}>{c.orders}</td>
                    <td className="py-2.5 pr-4 text-right tabular-nums font-semibold">
                      <span style={{ color: c.convRate >= 1.5 ? '#059669' : c.convRate >= 0.5 ? '#d97706' : '#e11d48' }}>
                        {c.convRate}%
                      </span>
                    </td>
                    <td className="py-2.5 pr-4 text-right tabular-nums" style={{ color: '#023c4699' }}>{fmtGBP(c.net)}</td>
                    <td className="py-2.5 pr-4 text-right tabular-nums font-semibold" style={{ color: '#023c46' }}>{c.gp > 0 ? fmtGBP(c.gp) : '—'}</td>
                    <td className="py-2.5 text-right tabular-nums" style={{ color: '#023c4699' }}>{c.aov > 0 ? fmtGBP2(c.aov) : '—'}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr style={{ borderTop: '2px solid #023c4622' }}>
                  <td className="py-2.5 pr-4 font-bold text-xs uppercase tracking-wider" style={{ color: '#023c46' }}>Total</td>
                  <td className="py-2.5 pr-4 text-right tabular-nums font-bold" style={{ color: '#023c46' }}>{channelData.reduce((s, c) => s + c.sessions, 0).toLocaleString()}</td>
                  <td className="py-2.5 pr-4 text-right tabular-nums font-bold" style={{ color: '#023c46' }}>{channelData.reduce((s, c) => s + c.orders, 0)}</td>
                  <td className="py-2.5 pr-4 text-right tabular-nums font-bold" style={{ color: '#023c46' }}>
                    {(channelData.reduce((s, c) => s + c.orders, 0) / channelData.reduce((s, c) => s + c.sessions, 0) * 100).toFixed(2)}%
                  </td>
                  <td className="py-2.5 pr-4 text-right tabular-nums font-bold" style={{ color: '#023c46' }}>{fmtGBP(channelData.reduce((s, c) => s + c.net, 0))}</td>
                  <td className="py-2.5 pr-4 text-right tabular-nums font-bold" style={{ color: '#023c46' }}>{fmtGBP(channelData.reduce((s, c) => s + c.gp, 0))}</td>
                  <td className="py-2.5 text-right tabular-nums font-bold" style={{ color: '#023c46' }}>
                    {fmtGBP2(channelData.filter(c => c.orders > 0).reduce((s, c) => s + c.net, 0) / channelData.filter(c => c.orders > 0).reduce((s, c) => s + c.orders, 0))}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
          <p className="text-xs mt-3" style={{ color: '#023c46', opacity: 0.3 }}>
            Est. GP = net revenue × 31.29% store avg margin · net revenue = GA4 purchase revenue ÷ 1.2 (VAT) adjusted to Metorik totals
          </p>
        </div>

        {/* Campaign table */}
        <div className="rounded-2xl border p-5 shadow-sm" style={{ background: '#ffffff', borderColor: '#023c4622' }}>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold" style={{ color: '#023c46' }}>Campaign Performance (30d)</h2>
            <span className="text-xs" style={{ color: '#023c46', opacity: 0.4 }}>ACOS overall: {acos.toFixed(1)}% · Avg AOV: {fmtGBP2(avgAov)}</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs uppercase tracking-wider" style={{ color: '#023c46', opacity: 0.45, borderBottom: '1px solid #023c4615' }}>
                  <th className="py-2 pr-4 font-semibold">Campaign</th>
                  <th className="py-2 pr-4 font-semibold text-right">Spend</th>
                  <th className="py-2 pr-4 font-semibold text-right">Conv. value</th>
                  <th className="py-2 pr-4 font-semibold text-right">Conversions</th>
                  <th className="py-2 pr-4 font-semibold text-right">ROAS</th>
                  <th className="py-2 font-semibold text-right">CTR</th>
                </tr>
              </thead>
              <tbody>
                {sortedCampaigns.map((c) => {
                  const roas = c.spend > 0 ? c.convValue / c.spend : 0;
                  const ctr = c.impr > 0 ? (c.clicks / c.impr) * 100 : 0;
                  return (
                    <tr key={c.name} className="last:border-0" style={{ borderBottom: '1px solid #023c460a' }}>
                      <td className="py-2.5 pr-4 font-medium" style={{ color: '#023c46' }}>{c.name}</td>
                      <td className="py-2.5 pr-4 text-right tabular-nums" style={{ color: '#023c4699' }}>{fmtGBP(c.spend)}</td>
                      <td className="py-2.5 pr-4 text-right tabular-nums" style={{ color: '#023c4699' }}>{fmtGBP(c.convValue)}</td>
                      <td className="py-2.5 pr-4 text-right tabular-nums" style={{ color: '#023c4699' }}>{c.conv.toFixed(1)}</td>
                      <td className="py-2.5 pr-4 text-right tabular-nums font-semibold">
                        <span style={{ color: roas >= 5 ? '#059669' : roas >= 2 ? '#d97706' : '#e11d48' }}>
                          {roas.toFixed(2)}x
                        </span>
                      </td>
                      <td className="py-2.5 text-right tabular-nums" style={{ color: '#023c4699' }}>{ctr.toFixed(2)}%</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        <p className="text-center text-xs mt-6" style={{ color: '#023c46', opacity: 0.35 }}>
          Data: WooCommerce (www.expressgolf.co.uk) &amp; Google Ads (Express Golf: Online), via Windsor.ai · last 30 days to 11 Jun 2026
        </p>
      </div>
    </div>
  );
}
